/* code goes here */
/*responsible for setting up event listeners on the page*/


/*initialize handler once page is ready*/
/* code goes here */

/*ensures form fields are not empty*/
/* code goes here */

	//loop thru the input elements looking for empty values
/* code goes here */

	
	//now set up the error message
/* code goes here */


