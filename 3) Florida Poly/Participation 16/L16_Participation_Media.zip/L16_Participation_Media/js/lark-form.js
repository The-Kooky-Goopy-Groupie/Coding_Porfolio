
// Determine if a field is blank
function isBlank(inputField){
    if (inputField.value=="") {
        return true;
    }
    return false;
}

// remove all error styles from the div passed in
function makeClean(element){
    element.classList.remove("error");		
}

// Wait until the page is loaded, before doing any DOM stuff

window.addEventListener("load", function() {    

    // add listeners for classes with hilightable ... 

    
    // add listeners for classes with required ... 


    //on submitting the form, "empty" checks are performed on required inputs

});