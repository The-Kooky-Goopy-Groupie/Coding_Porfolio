<?php
$b = "Fail!";
echo "The file upload was a ". $b;
?>
