<?php
$b = "Success!";
echo "The file upload was a ". $b;
?>
