﻿using System.Collections; // idk what this does
using NETWORK_ENGINE; // This is the prebuilt network engine
using UnityEngine; // pretty sure this is the general engine functions
using UnityEngine.UI; // this is for UI specific Stuff

public class ReadyUI : NetworkComponent // Why do we use NetworkComponet here? networkcomponet has all the built in functions, this intergrates those. it inhertits from monobehavior to give more classes
{
    public Text statusMessage; //Text Output that is displayed
    public bool IsReady = false; // used to tell if is ready... to do what?
    public string LastMessage ="";// this is last message a local player sends (synchronized severe variable)
    public InputField ChatBubble; // this is the Area that you type in the Chat Bubble

    // have sepaerate variables for the different flags
    public override void HandleMessage(string flag, string value)
    {
        if (flag == "OIS") {
            //  LastMessage = value;  would be an optimization as it checks regardless of the sever. 
            if (IsServer)
            {
                LastMessage = value; // set the last message sent by client to the last message variable.
                SendUpdate("OIS", value); // This sends the last message that was stored to the clients 
            }
            if (IsClient)
            {
                LastMessage = value; //shows that it stores the value 
                statusMessage.text = LastMessage; //render then the value that is outputed. you can statusMessage.text = value
            }
        }

        if (flag == "TOG") { // is used to check for the flag message from an object
            if (IsServer)
            {
                IsReady = bool.Parse(value); // Parse - all primatives have this, and this checks the type of item that, can even make own parse
                SendUpdate("TOG", value);
            }
            if (IsClient)
            {
                IsReady = bool.Parse(value);
                
                if(!IsLocalPlayer)
                {
                    //toggle.isOn = IsReady;
                }
                
                if (IsReady) // this area works
                {
                   // statusMessage.text = value ; // we want this equal to message  outputed in the things
                }
                else 
                {
                    //statusMessage.text = "";// if no input then turn blank?
                }
            
            }
        }
    }
    // only the instance that shares the forign network ID value will get this message

  

    public override IEnumerator SlowUpdate()
    {
        this.transform.position = new Vector3(-5 + Owner*10, 0, 0); // is used to make them display next to eachother
        if (!IsLocalPlayer)
        {
            ChatBubble.interactable = false; // this line here makes it where only the local player can use there own textbox
        }
        while(IsServer)
        {
            if (IsDirty) // is dirty is a way of client notifiying server that it needs to update, mainly for when a client joins late.
            {
                SendUpdate("OIS", LastMessage); // this sends the last message update to them 
                SendUpdate("TOG", IsReady.ToString());
                IsDirty = false;
            }
            yield return new WaitForSeconds(.1f);// keep in while loop or this causes a crash
        }
      
    }



    public void OnInputString(string statusMessage) //InputString we want to use this where after we press enter we send the string from client to serever rather then a bol
    {
        if (MyId.IsInit && IsLocalPlayer) // what does this mean?
        {
                SendCommand("OIS", statusMessage.ToString());  // used to check for the the string and send 
                //OIS = OnInputString
                // Can't have any network componets that have the same flag names
        }
    }
    public override void NetworkedStart() { } // we don't use this
    void Start() { } // not used
    void Update() { } // not used
}

// What we have to do for the code - make it where we send a string
/* test 1 didn't really work, we have input boxes that can be typed in but 
1. doesn't show anything for the text when typed in for other screens
2. doesn't seem to relay the info. it does always update to the debug tho
// Debug.Log(message); used to just make sure string is indeed being picked up
good news is were getting the string though!
*/