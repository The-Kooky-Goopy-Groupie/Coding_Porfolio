

//$(':password').css('background-color', 'yellow');


$('label:contains("word")').css("color", "black");

$('form :nth-child(4n)').css('background-color', 'yellow');

//$( "#email" ).prop( "disabled", false );