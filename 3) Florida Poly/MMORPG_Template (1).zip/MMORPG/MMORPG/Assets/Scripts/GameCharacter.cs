﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using NETWORK_ENGINE;

public class GameCharacter : NetworkComponent
{
    public string Pname;
    public int Color;
    public Text MyTextbox;
    public int Score = 0;

    public GameObject AttackBox;

    public IEnumerator DisableAttack()
    {
        yield return new WaitForSeconds(.3f);
        AttackBox.SetActive(false);
        //Another wait
        //CanShoot =true;
    }

    public override void HandleMessage(string flag, string value)
    {
        if(flag == "PNAME")
        {
            Pname = value;
            MyTextbox.text = value;
        }
        if(flag == "MOVE")
        {
            string[] args = value.Split(',');
            Vector3 moveTemp = new Vector3(int.Parse(args[0]), 0, int.Parse(args[1]))*3;//I should use existing Y velocity to prevent floating. 
            gameObject.GetComponent<Rigidbody>().velocity = moveTemp;
        }
        if(flag == "SCORE")
        {
            Score = int.Parse(value);
        }
        if(flag == "SHOOT")
        {
            //Can shoot?
            AttackBox.SetActive(true);
            StartCoroutine(DisableAttack());
            //Server
            //Spawn the bullet.
            //GameObject temp = MyCore.NetCreateObject(< index in spawn array >, Owner, this.transform.position);
            //temp.GetComponent<Rigidbody>().velocity = this.transform.forward * 4//bullet speed;
        }

        /*if(flag == "COLOR")
         * {//Client side
         * color = value;
         * if(color == 1)
         * {
         * MyRenderer.color = Color32.Blue;
         * }
         * 
         * }*/
    }

    public override IEnumerator SlowUpdate()
    {
        while (true)
        {
            //Player contoller
            if (IsLocalPlayer)
            {
                float h = Input.GetAxisRaw("Horizontal");
                float v = Input.GetAxisRaw("Vertical");
                SendCommand("MOVE", h + "," + v);
                if(Input.GetAxisRaw("Jump")>0)
                {
                    SendCommand("SHOOT", "1");
                }
                //if(<Space is pressed> && CanShoot)
                //{
                //SendCommand("SHOOT","1");
                //}
            }

            if(IsServer)
            {

                if(IsDirty)
                {
                    SendUpdate("PNAME", Pname);
                    MyTextbox.text = Pname;

                    //SendUPdate("COLOR",color.ToString());
                    //Send Player Options to the clients.
                    //Synchronize all parameters.        

                    IsDirty = false;
                }
            }
            yield return new WaitForSeconds(MyCore.MasterTimer);
        }
    }

    //Collisions

    //Triggers
    private void OnTriggerEnter(Collider other)
    {
        BoxCollider myBody = GetComponent<BoxCollider>();
        if(IsServer)
        {
            if(other.tag == "Coin")
            {
                Score++;
                SendUpdate("SCORE", Score.ToString());
                MyCore.NetDestroyObject(other.gameObject.GetComponent<NetworkID>().NetId);
            }
            //List of trigger objects to deal with.
            if(other.tag == "Finish" && myBody == other)
            {
                //send to start location
                GameObject[] startlocations = GameObject.FindGameObjectsWithTag("Respawn");
                this.gameObject.GetComponent<Rigidbody>().position = startlocations[Owner].transform.position; //Start location...
            }

        }
        if(IsClient)
        {
            if(other.tag == "Finish")
            {
                //Play sound affect.
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
