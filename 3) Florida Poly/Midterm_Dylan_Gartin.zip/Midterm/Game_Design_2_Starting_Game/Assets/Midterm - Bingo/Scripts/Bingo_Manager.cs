﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NETWORK_ENGINE;
using UnityEngine.UI; // technically this line here is not needed but it's not like he comminting mureder


// Edits that need to be done here -
/*

 
 */
public class Bingo_Manager : NetworkComponent
{
    public bool GameStarted = false; // makes sure game is not started at the start
    public Image LobbyBackground;

    public int BingoRandNumber; // the Random number picked by the bingo generator
    public bool BingoWinner = false; // Check to see if there is a winner 

    public int[,] Numbers = new int[5, 5];

    public override void HandleMessage(string flag, string value)
    {
        if (flag == "GAMESTART") // checks that a game has started
        {
            GameStarted = true;
            foreach (Bingo_Lobby lp in GameObject.FindObjectsOfType<Bingo_Lobby>())
            {
                lp.transform.GetChild(0).gameObject.SetActive(false); // OH WAITT THIS IS DEACTIVATING THE LOBBY SCREENS HOW DID I NOT GET THAT
            }

        }



      // Below is the logic for the bingo board         
      
        if (IsClient)
        {
            if (flag == "RANDOMNUM")
            {
                BingoRandNumber = int.Parse(value);
                foreach (Bingo_Player lp in GameObject.FindObjectsOfType<Bingo_Player>()) // finding every network player lobby script and making an array of them
                {
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (lp.Numbers[i, j] == BingoRandNumber)
                            {
                                lp.UiUpdate[(5 * i) + j].color = Color.white; // thise doesn't work since is the bool array we need to make it the grid array point color to white
                                lp.NumberChecker[i, j] = true; // in case there needed logic on client end
                            }
                        }
                    }

                }
            }
        }
    }

    // repeat the same check here to mark the server cards, but get the number from the server, and then also do not run any of the winner code}

    /* 
     Thinky tank
     
     GameObject newGO = new GameObject("myTextGO");
              ngo.transform.SetParent(this.transform);

              Text myText = ngo.AddComponent<Text>();
              myText.text = "Ta-dah!";
    
     */
    public override IEnumerator SlowUpdate()
    {
        // where the maagic happens
        while (!GameStarted && IsServer) // assumse that the game can start at the start
        {
            bool readyGo = true;
            int count = 0;
            foreach (Bingo_Lobby lp in GameObject.FindObjectsOfType<Bingo_Lobby>())
            {
                if (!lp.IsReady) // checking if the check is not ready
                {
                    readyGo = false;
                    break;
                }
                count++;
            }
            if (count < 2) // can't start with only one player
            {
                readyGo = false;
            }
            GameStarted = readyGo;
            yield return new WaitForSeconds(2);
        }
        if (IsServer)
        {
            SendUpdate("GAMESTART", GameStarted.ToString());

            foreach (Bingo_Lobby lp in GameObject.FindObjectsOfType<Bingo_Lobby>())
            {
                MyCore.NetCreateObject(lp.Player_Board, lp.Owner, lp.transform.position, Quaternion.identity);

            }
        }

        while (IsServer)
        {
                if (BingoWinner == false) // assume nobody has won at the start of the game
                {
                    BingoRandNumber = Random.Range(1, 75); // generate the random number on the server end
                    System.Console.Write("" + BingoRandNumber); // used to check number generation
                    foreach (Bingo_Player lp in GameObject.FindObjectsOfType<Bingo_Player>()) // finding every network player lobby script and making an array of them
                    {

                        for (int i = 0; i < 5; ++i)// this goes through each of the column items
                        {
                            for (int j = 0; j < 5; ++j)// this goes through each of the column items
                            {
                                if (lp.Numbers[i, j] == BingoRandNumber)// if (bingoRandNumber = this )  if ( the array textbox = BingoRandNumber.ToString())
                                {
                                    // make the array list element a diffeent color GetComponent<Text>([i,j]).UiTextTable = Color.magenta; 
                                    lp.NumberChecker[i, j] = true; // this makes this slot true on each card
                                                                   // change color here if client

                                }
                            }
                        }
                        SendUpdate("RANDOMNUM", BingoRandNumber.ToString()); // in handle message going to parse out this message and  only needs to be sent once
                    // not sending this / updating it on client end

                        if (true) // win condition is met where 5 in a row happens check for 5 slahes 
                        {
                            //check for the / in order to find if there a bingo
                        }
                    }
                    new WaitForSeconds(1.0f); // used to put a one second delay between number generation
                }
                else // if it equal true meaning win is obtained
                {
                    // output who has won here Text Victory.text = "Ta-dah! This Game Winner is"+ Nametxt of bingo player who has won;
                    new WaitForSeconds(20.0f); // wait to let the player bask in glory 
                    StartCoroutine(MyCore.DisconnectServer());// end the server here
                                                              // // end the server here  Application.Quit(); yeah this is dissconect but we don't know the right syntax but this is fine atm
                }
            
            if (IsDirty)
            {
                SendUpdate("GAMESTART", GameStarted.ToString());
                IsDirty = false;
            }
            yield return new WaitForSeconds(1);
        }
    }



    // Start is called before the first frame update
    void Start()
    {
        GameStarted = false; // oh hey your not useless this time! good for you! makes sure game doesn't auto start
    }


    void Update()
    {

    }
    public override void NetworkedStart()
    {
        // populate the numbers
    }
  
    
    
    /*if the UI itself starts to scale out where it crosses over eachother use the scale item in order to try and bring it back*/
}
