﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NETWORK_ENGINE;
using UnityEngine.UI;


// Edits that need to be done here -
/*
 
 
 */
public class Bingo_Lobby : NetworkComponent
{

    public int Player_Color; // the color of the player
    public bool IsReady = false; // check to see if game is ready

    // The UI Elements 
    public Toggle ReadyToggle; // toggle for the player being ready
    public Image LobbyBackground; // used to give the different background colors to the panes

    // The below are the name items for code
    public Text statusMessage; // Client end name
    public string LastMessage = "NULL"; // sent string
    public InputField ChatBubble; // place to input the string

    // The new Variables


    public int Player_Board; // Int to make the boards?

    // The Bingo Random number generation Varriables
    public int B = 0; // Random.Range(1, 15); // No they're not suppose to be set here they have to generate with the board
    public int I = 0; // Random.Range(16, 30);
    public int N = 0; // Random.Range(31, 45);
    public int G = 0; // Random.Range(46, 60);
    public int O = 0; // Random.Range(61, 75);

    // The 
    public int Bingo_Ball_Number = 0; // Random.Range(1, 75); // will generate a random number and send to players

    public override void HandleMessage(string flag, string value)
    {
        switch (flag) // check for any of the flag messages
        {
            case "COLOR": // This is to set the team color
                Player_Color = int.Parse(value.ToString());
                if (IsServer)
                {
                    SendUpdate("COLOR", value); // used to send back the team values to the client
                }
                if (IsClient)
                {
                    /*switch (Player_Color)
                    {// check that my order matches, bugged that it only changes bkgn color.
                        case 0: // RED
                            LobbyBackground.color = new Color(255, 0, 0, 128);
                            break;
                        case 1: //Blue
                            LobbyBackground.color = new Color(0, 0, 255, 128);
                            break;
                        case 2: // Green 
                            LobbyBackground.color = new Color(0, 255, 0, 128);
                            break;
                        case 3: // Yellow
                            LobbyBackground.color = new Color(255, 255, 0, 128);
                            break;
                    }*/
                }
                break;




            //check the character selection    
            case "BOARD":
                 Player_Board = int.Parse(value.ToString()); // checks over the value of the charactor string and returns it
                if (IsServer)
                {
                    SendUpdate("BOARD", value);
                }
                break;




//checks if the player is ready this area shouldn't change form the 
            case "READY":
                IsReady = bool.Parse(value.ToString());
                if (IsClient)
                {
                    ReadyToggle.isOn = IsReady;
                    /*disable the toggle
                     if(IsReady)
                    {
                    ReadyToggle.interactable = false;
                    }*/
                }
                if (IsServer)
                {
                    SendUpdate("READY", value); // used to check if everyone is ready and send back the info
                    if (IsReady)
                    {
                     //-1 is wrong, put owner if it controled by the player, -1 is for the server objects, since the server is creating this for the player we must use owner
                     //  MyCore.NetCreateObject(Character, Owner, this.transform.position - new Vector3(0, .5f, 0), Quaternion.identity);
                     // this is used in unsyncronized start for the above and the toggle interactable off
                     // thus the above spawns the player character, used for asyncronyis start.
                    }
                }
                break;

            case "NAME": // This case is used to set the name of the player
                //  LastMessage = value;  would be an optimization as it checks regardless of the sever. 
                if (IsServer)
                {
                    LastMessage = value; // set the last message sent by client to the last message variable.
                    SendUpdate("NAME", value); // This sends the last message that was stored to the clients 
                }
                if (IsClient)
                {
                    LastMessage = value; //shows that it stores the value 
                    statusMessage.text = LastMessage; //render then the value that is outputed. you can statusMessage.text = value
                }
                break;
        }
    }



    public override IEnumerator SlowUpdate()
    {
        if (!IsLocalPlayer) // makes sure only the one who is the local player can use the string.
        {
            ReadyToggle.interactable = false;
            ChatBubble.interactable = false;
        }
// Keep this
        switch (Owner) // Used to display the 4 canvas onto the screen. more hackish, would be better to have a canvas that has a grid layout and makes panels
        {
            case 0:
                this.transform.position = new Vector3(-5.5f, 5.5f, 10);
                break;
            case 1:
                this.transform.position = new Vector3(5.5f, 5.5f, 10);
                break;
            case 2:
                this.transform.position = new Vector3(-5.5f, -5.5f, 10);
                break;
            case 3:
                this.transform.position = new Vector3(5.5f, -5.5f, 10);
                break;
        }

        while (MyCore.IsConnected) // test  if Mycore. is needed
        {
            if (IsLocalPlayer)
            {
                // input can go here
                // Any local player only notifications
            }
            if (IsClient)
            {
                // everyone who is on the server is there
            }
            if (IsServer)
            {
                // all logic that affects the gamestates goes here
                if (IsDirty) // is used to check that all the objects are up to date
                {
                    SendUpdate("READY", IsReady.ToString());
                    SendUpdate("BOARD", Player_Board.ToString());
                    SendUpdate("COLOR", Player_Color.ToString());
                    SendUpdate("NAME", LastMessage);
                    IsDirty = false; // having the Is Dirty actually solves the default check issue that could occur
                }
            }
            yield return new WaitForSeconds(.1f);
        }
    }



    // below are sending the commands to the server codes
    public void SetCOLOR(int c)
    {
        if (IsLocalPlayer && MyId.IsInit)
        {
            SendCommand("COLOR", c.ToString()); // This code is used to send the color id, color should be set to red for player 1, blue player 2, green player 3, and yellow player 4
        }
    }

    public void SetBoard(int b)
    {
        if (IsLocalPlayer && MyId.IsInit)
        {
            SendCommand("BOARD", b.ToString());// This will be the message sent to set up the boards, which is used to generate them.
        }
    }
    public void SetReady(bool r)
    {
        if (IsLocalPlayer && MyId.IsInit)
        {
            SendCommand("READY", r.ToString()); // this will happen after everyone is ready. i think this area also handles the number generation?
        }
    }

    public void OnNameSet(string statusMessage) //InputString we want to use this where after we press enter we send the string from client to serever rather then a bol
    {
        if (MyId.IsInit && IsLocalPlayer) // what does this mean?
        {
            SendCommand("NAME", statusMessage.ToString()); // used to check for the the string and send //OIS = OnInputString// Can't have any network componets that have the same flag names       
        }
    }

    //None of the below is really needed
    // Start is called before the first frame update
    void Start()
    {
    }
    // Update is called once per frame
    void Update()
    {
    }
    public override void NetworkedStart()
    { // Owner = the Player ID that is this 
        switch (this.Owner)
        {
            case 0: // RED
                LobbyBackground.color = new Color(255, 0, 0, 128);
                break;
            case 1: //Blue
                LobbyBackground.color = new Color(0, 0, 255, 128);
                break;
            case 2: // Green 
                LobbyBackground.color = new Color(0, 255, 0, 128);
                break;
            case 3: // Yellow
                LobbyBackground.color = new Color(255, 255, 0, 128);
                break;
        }
    }
}

// Current Issue - Doesn't show the UI at all, acts as if it instantly goes into the game
// things to note,
// build seems to say it is still building the network componet even though is different object