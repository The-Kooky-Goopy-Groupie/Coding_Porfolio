﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NETWORK_ENGINE;
using UnityEngine.UI;


// Edits that need to be done here -
/*
 Okay so this area generates the base player and such for the game, i don't think this area needs the edits then perhaps???

 */
public class Bingo_Player : NetworkComponent 
{
     
    // Textbox entry Item
    public Text UiText;
    public string NameTxt = "NULL";
    public Text[] UiUpdate;

    // Color of each bingo board
    public int Player_Color;
    public Image LobbyBackground;

    public int[,] Numbers = new int [5,5]; // 2D array that is a 5 by 5 array first is row 2nd is column

    public bool[,] NumberChecker = new bool[5, 5]; // 2D array to check that by default auto false
 public override IEnumerator SlowUpdate()
    {
        foreach (Bingo_Lobby lp in GameObject.FindObjectsOfType<Bingo_Lobby>()) // finding every network player lobby script and making an array of them
        {
            if (lp.Owner == this.Owner) // checks that this person is the script owner
            {
                NameTxt = lp.LastMessage; // these two set the name of the object
                UiText.text = NameTxt;
            
                yield return new WaitUntil(() => lp.IsReady);
              /*  Player_Color = lp.Player_Color;

                switch (Player_Color) // used to make each bingo board a different color
                {
                    case 0:
                        this.GetComponent<Renderer>().material.color = new Color32(255, 0, 0, 255);
                        break;
                    case 1:
                        this.GetComponent<Renderer>().material.color = new Color32(0, 0, 255, 255);
                        break;
                    case 2:
                        this.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 255);
                        break;
                    case 3: // 
                        this.GetComponent<Renderer>().material.color = new Color(255, 255, 0, 128);

                        break;
                }
                */


            }
       
            if (IsServer)
            {
                if (IsDirty)
                {
                    SendUpdate("BINGOCARD", ArraytoString());
                    IsDirty = false;
                }
            }

        }
        yield return new WaitForSeconds(.1f);
    }



// none of the below should be needed i think

    public override void HandleMessage(string flag, string value)
    {
        if (IsClient)
        {
            switch (flag)
            {
                case "BINGOCARD":
                    StringtoArray(value);
                 UiUpdate = this.transform.GetChild(0).GetChild(1).gameObject.GetComponentsInChildren<Text>(); // should work on the ording in the hiearchy but may be off due to such
                 
                 for (int i = 0; i < 5; ++i)// this goes through each of the column items
                    {
                        for (int j = 0; j < 5; ++j)// this goes through each of the column items
                        {
                            //Numbers[i, j] = int.Parse(tmp[(5 * i) + j]);// turns the 1D array to 2D
                            UiUpdate[(5 * i) + j].text = Numbers[i, j].ToString();
                        }
                    }

                    //this.transform.GetChild(0).GetChild(1). Goes down the object tree to check them and get the objects
                    // need to change the value to the UI
                    break;
            
            } 
        }

    }

    public override void NetworkedStart()
    {
        switch (this.Owner) // for some reason this does not work?
        {
            case 0: // RED
                LobbyBackground.color = new Color(255, 0, 0, 128);
                break;
            case 1: //Blue
                LobbyBackground.color = new Color(0, 0, 255, 128);
                break;
            case 2: // Green 
                LobbyBackground.color = new Color(0, 255, 0, 128);
                break;
            case 3: // Yellow
                LobbyBackground.color = new Color(255, 255, 0, 128);
                break;
        }

        if (IsServer)
        {
            for (int j = 0; j < 5; ++j)// this goes through each of the column items
            {
                List<int> NumberPool = new List<int>(); // makes a list
                for (int t = 1; t < 16; t++)// to go through 1 - 15
                {
                    NumberPool.Add(t + (j * 15)); // gives correct nums through first column

                }
                for (int i = 0; i < 5; ++i)//this goes through each row
                {
                    int RD = Random.Range(0, NumberPool.Count - 1);
                    Numbers[i, j] = NumberPool[RD];
                    NumberPool.RemoveAt(RD);
                }
            }
            SendUpdate("BINGOCARD", ArraytoString()); // send the bingocard
        }


        // our guess for where bingo logic goes



    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
              
    }
    public string ArraytoString() // void = the type  
    {
        string tmp = "";
        for (int i = 0; i < 5; ++i)// this goes through each of the column items
        {
            for (int j = 0; j < 5; ++j)// this goes through each of the column items
            {
                tmp = tmp + Numbers[i, j] + "+";// makes array values into a long string, + is a delimter symbol that sepates them, by adding in a plus sign
            } 
        }
        return tmp; // take the array value and turn it into a string then return it here
    }
    // ""  = string value
    // '' = one character value 

    public void StringtoArray(string s)
    {
        // s.Split('+'); // single quote the plus to make a character
        string[] tmp = s.Split('+');// split up the string at the char value
        for (int i = 0; i < 5; ++i)// this goes through each of the column items
        {
            for (int j = 0; j < 5; ++j)// this goes through each of the column items
            {
                Numbers[i, j] = int.Parse(tmp[(5*i)+j]);// turns the 1D array to 2D
            }
        }
        // does not need to return anything since void.
    } 
}

